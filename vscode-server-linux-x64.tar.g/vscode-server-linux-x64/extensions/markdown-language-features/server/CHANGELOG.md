# Changelog

# 0.4.0-alpha.3 — June 2, 2023
- Pick up [Markdown Language Service](https://github.com/microsoft/vscode-markdown-languageservice) 0.4.0-alpha.3. See [CHANGELOG](https://github.com/microsoft/vscode-markdown-languageservice/blob/main/CHANGELOG.md#040-alpha3--may-30-2023) for details.

## 0.3.0 - March 28, 2023
- Pick up [Markdown Language Service](https://github.com/microsoft/vscode-markdown-languageservice) 0.3.0. See [CHANGELOG](https://github.com/microsoft/vscode-markdown-languageservice/blob/main/CHANGELOG.md#030--march-16-2023) for details.
